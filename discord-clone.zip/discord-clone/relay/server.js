const { WebSocketServer } = require('ws');
const EventStore = require('./store');

const PORT = process.env.PORT || 8080;

// Fix 3: MAX_CONNECTIONS erhöht von 10 auf 100, konfigurierbar via ENV
const MAX_CONNECTIONS = parseInt(process.env.MAX_CONNECTIONS, 10) || 100;

// Fix 1: Konfigurierbare Origin-Whitelist für WebSocket-Verbindungen
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS
    ? process.env.ALLOWED_ORIGINS.split(',')
    : ['http://localhost', 'https://localhost', 'http://127.0.0.1', 'https://127.0.0.1'];

// Fix 2: Rate Limiting Konfiguration
const RATE_LIMIT = {
    messagesPerMinute: parseInt(process.env.RATE_LIMIT_MESSAGES, 10) || 120,
    maxSubscriptions: parseInt(process.env.RATE_LIMIT_SUBS, 10) || 20,
    maxMessageSize: parseInt(process.env.RATE_LIMIT_MSG_SIZE, 10) || 65536, // 64KB
};

// Start server with async init (needed for ESM-only @noble/curves)
(async () => {
  // Dynamic imports for ESM-only modules
  const { sha256 } = await import('@noble/hashes/sha256');
  const { bytesToHex, hexToBytes } = await import('@noble/hashes/utils');
  const { schnorr } = await import('@noble/curves/secp256k1.js');

  const store = new EventStore();

  // Fix 1: WebSocket Origin Validation (C-08)
  const wss = new WebSocketServer({
    port: PORT,
    verifyClient: (info) => {
      const origin = info.origin || info.req.headers.origin;
      // WebSocket-Clients ohne Browser (Tools, CLI, etc.) haben keinen Origin
      if (!origin) return true;
      try {
        const parsedOrigin = new URL(origin).origin;
        const allowed = ALLOWED_ORIGINS.some(allowed => {
          try {
            return parsedOrigin === new URL(allowed).origin;
          } catch { return false; }
        });
        if (!allowed) {
          console.warn(`[SECURITY] Rejected connection from origin: ${origin}`);
        }
        return allowed;
      } catch {
        console.warn(`[SECURITY] Rejected connection with invalid origin: ${origin}`);
        return false; // Invalid origin = reject
      }
    }
  });

  // Map: WebSocket -> { pubkey, subscriptions: Map<subId, filter> }
  const clients = new Map();

  // Fix 2: Per-Connection Rate Limiting State
  const connectionState = new Map(); // ws -> { messageCount, lastReset }

  /**
   * Prüft ob eine Connection das Rate Limit überschritten hat.
   * Gibt true zurück wenn limitiert (= Nachricht droppen).
   */
  function checkRateLimit(ws) {
    const state = connectionState.get(ws);
    if (!state) return false;

    const now = Date.now();
    // Reset-Fenster: 60 Sekunden
    if (now - state.lastReset > 60000) {
      state.messageCount = 0;
      state.lastReset = now;
    }

    state.messageCount++;
    return state.messageCount > RATE_LIMIT.messagesPerMinute;
  }

  // Fix 4: Filter-Validierung für REQ Subscriptions
  function validateFilters(filters) {
    return filters.map(f => {
      // Erzwinge mindestens ein Filter-Kriterium — verhindere leere Filter {}
      const hasFilter = f.ids || f.authors || f.kinds || f['#e'] || f['#p'] || f.since || f.until;
      if (!hasFilter) {
        f.kinds = [1, 42]; // Default: nur standard text + channel message events
      }
      // Clampe limit auf maximal 100
      f.limit = Math.min(f.limit || 50, 100);
      return f;
    });
  }

  console.log(`NOSTR-Discord Relay running on ws://localhost:${PORT}`);
  console.log(`  Max connections: ${MAX_CONNECTIONS}`);
  console.log(`  Rate limit: ${RATE_LIMIT.messagesPerMinute} msg/min, max ${RATE_LIMIT.maxMessageSize} bytes/msg`);
  console.log(`  Allowed origins: ${ALLOWED_ORIGINS.join(', ')}`);

  function serializeEventForId(event) {
    return JSON.stringify([
      0,
      event.pubkey,
      event.created_at,
      event.kind,
      event.tags,
      event.content
    ]);
  }

  function computeEventId(event) {
    const serialized = serializeEventForId(event);
    const hash = sha256(new TextEncoder().encode(serialized));
    return bytesToHex(hash);
  }

  function verifySignature(event) {
    try {
      const eventId = computeEventId(event);
      if (eventId !== event.id) {
        console.log('Event ID mismatch:', eventId, '!=', event.id);
        return false;
      }
      // Verify schnorr signature
      const sigBytes = hexToBytes(event.sig);
      const idBytes = hexToBytes(event.id);
      const pubkeyBytes = hexToBytes(event.pubkey);
      return schnorr.verify(sigBytes, idBytes, pubkeyBytes);
    } catch (e) {
      console.error('Signature verification error:', e.message);
      return false;
    }
  }

  function matchesFilter(event, filter) {
    if (filter.ids && !filter.ids.includes(event.id)) return false;
    if (filter.kinds && !filter.kinds.includes(event.kind)) return false;
    if (filter.authors && !filter.authors.includes(event.pubkey)) return false;
    if (filter.since && event.created_at < filter.since) return false;
    if (filter.until && event.created_at > filter.until) return false;

    // Tag filters
    for (const [key, values] of Object.entries(filter)) {
      if (key.startsWith('#') && Array.isArray(values)) {
        const tagName = key.slice(1);
        const eventTagValues = event.tags
          .filter(t => t[0] === tagName)
          .map(t => t[1]);
        if (!values.some(v => eventTagValues.includes(v))) return false;
      }
    }

    return true;
  }

  function broadcastEvent(event, senderWs) {
    for (const [ws, client] of clients.entries()) {
      // Für Signaling-Events: nur an den Ziel-Pubkey senden
      if (event.kind === 25000) {
        const targetPubkey = event.tags.find(t => t[0] === 'p')?.[1];
        if (targetPubkey && client.pubkey !== targetPubkey) continue;
      }

      // Prüfe alle Subscriptions des Clients
      for (const [subId, filters] of client.subscriptions.entries()) {
        const filtersArray = Array.isArray(filters) ? filters : [filters];
        for (const filter of filtersArray) {
          if (matchesFilter(event, filter)) {
            try {
              ws.send(JSON.stringify(['EVENT', subId, event]));
            } catch (e) {
              console.error('Send error:', e.message);
            }
            break; // Nur einmal pro Subscription
          }
        }
      }
    }
  }

  function getOnlinePubkeys() {
    const pubkeys = [];
    for (const [ws, client] of clients.entries()) {
      if (client.pubkey && ws.readyState === 1) {
        pubkeys.push(client.pubkey);
      }
    }
    return [...new Set(pubkeys)];
  }

  wss.on('connection', (ws) => {
    if (clients.size >= MAX_CONNECTIONS) {
      ws.send(JSON.stringify(['NOTICE', `Server full. Max ${MAX_CONNECTIONS} connections.`]));
      ws.close();
      return;
    }

    const clientData = { pubkey: null, subscriptions: new Map() };
    clients.set(ws, clientData);

    // Fix 2: Rate Limiting State pro Connection initialisieren
    connectionState.set(ws, { messageCount: 0, lastReset: Date.now() });

    console.log(`Client connected. Total: ${clients.size}`);

    ws.on('message', (data) => {
      // Fix 2: Message Size Check VOR dem Parsen
      const rawMessage = data.toString();
      if (rawMessage.length > RATE_LIMIT.maxMessageSize) {
        console.warn(`[RATE_LIMIT] Message too large: ${rawMessage.length} bytes (max ${RATE_LIMIT.maxMessageSize})`);
        ws.send(JSON.stringify(['NOTICE', `Message too large. Max size: ${RATE_LIMIT.maxMessageSize} bytes`]));
        return;
      }

      // Fix 2: Rate Limit Check
      if (checkRateLimit(ws)) {
        console.warn(`[RATE_LIMIT] Client exceeded ${RATE_LIMIT.messagesPerMinute} messages/minute`);
        ws.send(JSON.stringify(['NOTICE', 'Rate limit exceeded. Please slow down.']));
        return;
      }

      let msg;
      try {
        msg = JSON.parse(rawMessage);
      } catch (e) {
        ws.send(JSON.stringify(['NOTICE', 'Invalid JSON']));
        return;
      }

      if (!Array.isArray(msg) || msg.length < 2) {
        ws.send(JSON.stringify(['NOTICE', 'Invalid message format']));
        return;
      }

      const type = msg[0];

      switch (type) {
        case 'EVENT': {
          const event = msg[1];

          // Validiere Event-Struktur
          if (!event || !event.id || !event.pubkey || !event.sig ||
              event.kind === undefined || event.content === undefined || !Array.isArray(event.tags)) {
            ws.send(JSON.stringify(['OK', event?.id || '', false, 'invalid: missing fields']));
            return;
          }

          // Validiere Signatur
          if (!verifySignature(event)) {
            ws.send(JSON.stringify(['OK', event.id, false, 'invalid: bad signature']));
            return;
          }

          // Setze Pubkey des Clients
          clientData.pubkey = event.pubkey;

          // Speichere Event (nicht für kind 25000)
          const saved = store.saveEvent(event);

          // Bestätige
          ws.send(JSON.stringify(['OK', event.id, true, '']));

          // Broadcast an alle passenden Subscriber
          broadcastEvent(event, ws);
          break;
        }

        case 'REQ': {
          const subId = msg[1];
          let filters = msg.slice(2); // Kann mehrere Filter haben

          if (!subId || filters.length === 0) {
            ws.send(JSON.stringify(['NOTICE', 'Invalid REQ']));
            return;
          }

          // Fix 2: Subscription Limit prüfen
          if (clientData.subscriptions.size >= RATE_LIMIT.maxSubscriptions) {
            console.warn(`[RATE_LIMIT] Client exceeded max subscriptions (${RATE_LIMIT.maxSubscriptions})`);
            ws.send(JSON.stringify(['NOTICE', `Too many subscriptions. Max: ${RATE_LIMIT.maxSubscriptions}`]));
            return;
          }

          // Fix 4: Filter validieren (clampe limit, verhindere leere Filter)
          filters = validateFilters(filters);

          // Speichere Subscription
          clientData.subscriptions.set(subId, filters);

          // Sende gespeicherte Events die zum Filter passen
          for (const filter of filters) {
            const events = store.queryEvents(filter);
            // Events in chronologischer Reihenfolge senden
            events.reverse().forEach(event => {
              ws.send(JSON.stringify(['EVENT', subId, event]));
            });
          }

          // End of stored events
          ws.send(JSON.stringify(['EOSE', subId]));
          break;
        }

        case 'CLOSE': {
          const subId = msg[1];
          clientData.subscriptions.delete(subId);
          break;
        }

        default:
          ws.send(JSON.stringify(['NOTICE', `Unknown message type: ${type}`]));
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      // Fix 2: Rate Limiting State aufräumen
      connectionState.delete(ws);
      console.log(`Client disconnected. Total: ${clients.size}`);
    });

    ws.on('error', (err) => {
      console.error('WebSocket error:', err.message);
      clients.delete(ws);
      // Fix 2: Rate Limiting State aufräumen
      connectionState.delete(ws);
    });
  });

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\nShutting down...');
    store.close();
    wss.close();
    process.exit(0);
  });
})();
