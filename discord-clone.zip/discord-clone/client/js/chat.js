// chat.js - Text Chat Logic (P2P / Yjs CRDT + E2E Encryption + Schnorr Signatures)

const NostrChat = (() => {
  let currentChannel = 'allgemein';
  let keyPair = null;
  let renderedMessages = new Set();
  let nicknameCache = {};
  let avatarCache = {};
  let observer = null;

  const DEFAULT_CHANNELS = ['allgemein', 'gaming', 'random', 'musik', 'dev'];

  function init(keys) {
    keyPair = keys;

    P2P.onMetaUpdate((pubkey, meta) => {
      if (meta.nickname) {
        nicknameCache[pubkey] = meta.nickname;
      }
      if (meta.avatar) {
        avatarCache[pubkey] = meta.avatar;
      }
      updateDisplayedUser(pubkey);
      updateOnlineUser(pubkey, meta.verified);
    });

    P2P.onPeerJoin(peerId => {});

    P2P.onPeerLeave((peerId, peerInfo) => {
      if (peerInfo && peerInfo.pubkey) {
        removeOnlineUser(peerInfo.pubkey);
      }
    });
  }

  function updateDisplayedUser(pubkey) {
    const name = getDisplayName(pubkey);
    const avatar = avatarCache[pubkey];

    document.querySelectorAll(`.msg-author[data-pubkey="${pubkey}"]`).forEach(el => {
      el.textContent = name;
    });

    document.querySelectorAll(`.message[data-pubkey="${pubkey}"] .message-avatar`).forEach(el => {
      el.innerHTML = '';
      if (avatar && /^data:image\/[a-zA-Z+]+;base64,/.test(avatar)) {
        const img = document.createElement('img');
        img.className = 'avatar-img';
        img.src = avatar;
        img.alt = '';
        el.appendChild(img);
      } else {
        el.textContent = (name || '?').charAt(0).toUpperCase();
      }
    });

    document.querySelectorAll(`.user-item[data-pubkey="${pubkey}"] .user-name`).forEach(el => {
      el.textContent = name;
    });
    document.querySelectorAll(`.user-item[data-pubkey="${pubkey}"] .user-avatar-small`).forEach(el => {
      el.innerHTML = '';
      if (avatar && /^data:image\/[a-zA-Z+]+;base64,/.test(avatar)) {
        const img = document.createElement('img');
        img.className = 'avatar-img';
        img.src = avatar;
        img.alt = '';
        el.appendChild(img);
      } else {
        el.textContent = (name || '?').charAt(0).toUpperCase();
      }
    });

    document.querySelectorAll(`.voice-user[data-pubkey="${pubkey}"] .user-name`).forEach(el => {
      el.textContent = name;
    });
  }

  function updateOnlineUser(pubkey, verified) {
    const onlineList = document.getElementById('online-users');
    if (!onlineList) return;

    const name = getDisplayName(pubkey);
    const avatar = avatarCache[pubkey];
    const isVerified = verified || P2P.isPubkeyVerified(pubkey);

    let userItem = onlineList.querySelector(`.user-item[data-pubkey="${pubkey}"]`);
    if (!userItem) {
      userItem = document.createElement('div');
      userItem.className = 'user-item';
      userItem.dataset.pubkey = pubkey;
      onlineList.appendChild(userItem);
    }

    const manuallyVerified = NostrCrypto.isManuallyVerified(pubkey);
    let verifiedBadge;
    if (manuallyVerified) {
      verifiedBadge = '<span class="verified-badge manual" title="Manuell verifiziert (Emoji-Check)">&#9989;</span>';
    } else if (isVerified) {
      verifiedBadge = '<span class="verified-badge" title="Automatisch verifiziert (Challenge-Response)">&#129302;</span>';
    } else {
      verifiedBadge = '<span class="unverified-badge" title="Nicht verifiziert">&#9888;&#65039;</span>';
    }

    // Build user item safely
    userItem.innerHTML = '';

    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'user-avatar-small';
    if (avatar && /^data:image\/[a-zA-Z+]+;base64,/.test(avatar)) {
      const img = document.createElement('img');
      img.className = 'avatar-img';
      img.src = avatar;
      img.alt = '';
      avatarDiv.appendChild(img);
    } else {
      avatarDiv.textContent = (name || '?').charAt(0).toUpperCase();
    }

    const nameSpan = document.createElement('span');
    nameSpan.className = 'user-name';
    nameSpan.textContent = name;

    userItem.appendChild(avatarDiv);
    userItem.appendChild(nameSpan);

    // Verified badge is static HTML with no user data - safe to use innerHTML
    const badgeWrapper = document.createElement('span');
    badgeWrapper.innerHTML = verifiedBadge;
    userItem.appendChild(badgeWrapper.firstChild);

    // Make clickable for emoji verification
    userItem.style.cursor = 'pointer';
    userItem.onclick = () => showEmojiVerification(pubkey, name);
  }

  function removeOnlineUser(pubkey) {
    const onlineList = document.getElementById('online-users');
    if (!onlineList) return;
    const item = onlineList.querySelector(`.user-item[data-pubkey="${pubkey}"]`);
    if (item) item.remove();
  }

  // ====== EMOJI VERIFICATION MODAL ======

  function showEmojiVerification(pubkey, nickname) {
    if (!keyPair || pubkey === keyPair.publicKey) return;

    const modal = document.getElementById('emoji-verify-modal');
    if (!modal) return;

    const nameEl = document.getElementById('emoji-verify-name');
    const fpEl = document.getElementById('emoji-verify-fingerprint');
    const pubkeyEl = document.getElementById('emoji-verify-pubkey');
    const confirmBtn = document.getElementById('emoji-verify-confirm');
    const denyBtn = document.getElementById('emoji-verify-deny');
    const closeBtn = document.getElementById('emoji-verify-close');
    const statusEl = document.getElementById('emoji-verify-status');

    nameEl.textContent = nickname || NostrCrypto.shortenPubkey(pubkey);
    fpEl.textContent = NostrCrypto.emojiFingerprint(keyPair.publicKey, pubkey);
    pubkeyEl.textContent = pubkey;
    statusEl.style.display = 'none';

    // Reset buttons
    confirmBtn.disabled = false;
    denyBtn.disabled = false;

    const cleanup = () => { modal.style.display = 'none'; };

    confirmBtn.onclick = () => {
      NostrCrypto.setManuallyVerified(pubkey, true);
      statusEl.className = 'emoji-verify-status verified';
      statusEl.textContent = '\u2705 Peer als vertrauenswuerdig markiert';
      statusEl.style.display = 'block';
      confirmBtn.disabled = true;
      denyBtn.disabled = true;
      // Update peer list display
      updateOnlineUser(pubkey, true);
    };

    denyBtn.onclick = () => {
      NostrCrypto.setManuallyVerified(pubkey, false);
      statusEl.className = 'emoji-verify-status untrusted';
      statusEl.textContent = '\u26A0\uFE0F WARNUNG: Peer als nicht vertrauenswuerdig markiert!';
      statusEl.style.display = 'block';
      confirmBtn.disabled = true;
      denyBtn.disabled = true;
      Toast.show('warning', 'Nicht verifiziert', nickname + ' konnte nicht verifiziert werden. Vorsicht bei sensiblen Nachrichten.');
      updateOnlineUser(pubkey, false);
    };

    closeBtn.onclick = cleanup;

    modal.style.display = 'flex';
  }

  function getDisplayName(pubkey) {
    if (nicknameCache[pubkey]) return nicknameCache[pubkey];
    return NostrCrypto.shortenPubkey(pubkey);
  }

  function getAvatarUrl(pubkey) {
    return avatarCache[pubkey] || null;
  }

  function setLocalAvatar(pubkey, dataUrl) {
    if (dataUrl) {
      avatarCache[pubkey] = dataUrl;
    }
  }

  function publishNickname(nickname) {
    NostrCrypto.setNickname(nickname);
    nicknameCache[keyPair.publicKey] = nickname;

    const avatar = NostrCrypto.getAvatar();
    if (avatar) {
      avatarCache[keyPair.publicKey] = avatar;
    }

    P2P.broadcastMeta();
  }

  function switchChannel(channel) {
    if (observer) {
      const oldMessages = P2P.getMessages(currentChannel);
      if (oldMessages) {
        oldMessages.unobserve(observer);
      }
    }

    currentChannel = channel;
    renderedMessages.clear();

    const messagesEl = document.getElementById('messages');
    if (messagesEl) messagesEl.innerHTML = '';

    document.querySelectorAll('.channel-item').forEach(el => {
      el.classList.toggle('active', el.dataset.channel === channel);
    });

    const channelNameEl = document.getElementById('current-channel-name');
    if (channelNameEl) channelNameEl.textContent = '# ' + channel;

    const yMessages = P2P.getMessages(channel);
    if (!yMessages) return;

    // Render existing messages (async - decrypt + verify)
    const existing = yMessages.toArray();
    for (const msg of existing) {
      if (!renderedMessages.has(msg.id)) {
        renderedMessages.add(msg.id);
        renderMessage(msg);
      }
    }

    if (messagesEl) {
      setTimeout(() => { messagesEl.scrollTop = messagesEl.scrollHeight; }, 50);
    }

    observer = (event) => {
      event.changes.added.forEach(item => {
        item.content.getContent().forEach(msg => {
          if (msg && msg.id && !renderedMessages.has(msg.id)) {
            renderedMessages.add(msg.id);
            renderMessage(msg);
          }
        });
      });
    };
    yMessages.observe(observer);
  }

  async function sendMessage(text) {
    if (!text.trim()) return;

    const content = text.trim();
    const created_at = Math.floor(Date.now() / 1000);

    // Sign the plaintext message with Schnorr
    const sig = await NostrCrypto.signMessagePayload(
      keyPair.publicKey, created_at, currentChannel, content, keyPair.privateKey
    );

    const msg = {
      id: keyPair.publicKey.slice(0, 8) + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
      pubkey: keyPair.publicKey,
      channel: currentChannel,
      created_at: created_at,
      sig: sig // Schnorr signature over plaintext
    };

    // Layer 1: Ratchet encryption (forward secrecy) if available
    if (Ratchet.getChainIndex() >= 0) {
      try {
        const ratcheted = await Ratchet.encrypt(content);
        msg.ratchet = ratcheted; // { iv, ct, ci }
      } catch (e) {
        console.warn('Ratchet encrypt failed, falling back to room key:', e);
      }
    }

    // Layer 2: Room key encryption (if no ratchet or as fallback)
    if (!msg.ratchet) {
      const encrypted = await NostrCrypto.encryptText(content);
      if (encrypted) {
        msg.encrypted = encrypted;
      } else {
        msg.content = content;
      }
    }

    const yMessages = P2P.getMessages(currentChannel);
    if (yMessages) {
      yMessages.push([msg]);
    }

    // Update delivery status after a tick (once rendered)
    setTimeout(() => updateDeliveryStatus(msg.id), 50);
  }

  // Update delivery status for a sent message
  function updateDeliveryStatus(msgId) {
    const msgEl = document.querySelector(`.message[data-msg-id="${msgId}"]`);
    if (!msgEl) return;

    const deliveryEl = msgEl.querySelector('.msg-delivery');
    if (!deliveryEl) return;

    const peerCount = P2P.getPeerCount();
    if (peerCount === 0) {
      deliveryEl.className = 'msg-delivery pending';
      deliveryEl.textContent = '\u23F3';
      deliveryEl.title = 'Kein Peer verbunden';
    } else {
      deliveryEl.className = 'msg-delivery sent';
      deliveryEl.textContent = '\u2713';
      deliveryEl.title = 'Gesendet';
      // Mark as delivered after Yjs sync (short delay for propagation)
      setTimeout(() => {
        if (deliveryEl && P2P.getPeerCount() > 0) {
          deliveryEl.className = 'msg-delivery delivered';
          deliveryEl.textContent = '\u2713\u2713';
          deliveryEl.title = 'Zugestellt';
        }
      }, 2000);
    }
  }

  // Async render: decrypt + verify + display
  async function renderMessage(msg) {
    const messagesEl = document.getElementById('messages');
    if (!messagesEl) return;

    let content = null;
    let isEncrypted = false;
    let isRatcheted = false;
    let decryptFailed = false;
    let sigValid = false;
    let hasSig = !!msg.sig;

    // Step 1: Decrypt - try ratchet first, then room key, then plaintext
    if (msg.ratchet) {
      isRatcheted = true;
      isEncrypted = true;
      content = await Ratchet.decrypt(msg.pubkey, msg.ratchet);
      if (content === null) {
        decryptFailed = true;
      }
    } else if (msg.encrypted) {
      isEncrypted = true;
      content = await NostrCrypto.decryptText(msg.encrypted);
      if (content === null) {
        decryptFailed = true;
      }
    } else if (msg.content) {
      content = msg.content;
    }

    // Step 2: Verify Schnorr signature
    if (hasSig && content && !decryptFailed) {
      sigValid = await NostrCrypto.verifyMessageSignature(
        msg.pubkey, msg.created_at, msg.channel, content, msg.sig
      );
    }

    const isOwn = msg.pubkey === keyPair.publicKey;
    const time = new Date(msg.created_at * 1000);
    const timeStr = time.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    const dateStr = time.toLocaleDateString('de-DE');
    const displayName = getDisplayName(msg.pubkey);

    const avatarUrl = avatarCache[msg.pubkey];

    // Security badges
    let badges = '';
    if (isRatcheted && !decryptFailed) {
      badges += '<span class="badge badge-ratchet" title="Forward Secrecy (Sender Key Ratchet)">&#128737;</span>';
    } else if (isEncrypted && !decryptFailed) {
      badges += '<span class="badge badge-encrypted" title="E2E verschluesselt">&#128274;</span>';
    } else if (isEncrypted && decryptFailed) {
      badges += '<span class="badge badge-decrypt-failed" title="Entschluesselung fehlgeschlagen">&#128275;</span>';
    }
    if (hasSig && sigValid) {
      badges += '<span class="badge badge-verified" title="Signatur verifiziert">&#10003;</span>';
    } else if (hasSig && !sigValid && !decryptFailed) {
      badges += '<span class="badge badge-forged" title="WARNUNG: Signatur ungueltig!">&#9888;</span>';
    } else if (!hasSig) {
      badges += '<span class="badge badge-unsigned" title="Nicht signiert (Legacy)">&#63;</span>';
    }

    // Display content
    let displayContent;
    if (decryptFailed) {
      displayContent = '<span class="encrypted-placeholder">&#128274; Verschluesselte Nachricht (falsches Passwort?)</span>';
    } else if (content) {
      displayContent = formatContent(content);
    } else {
      displayContent = '<span class="encrypted-placeholder">&#128274; Unlesbar</span>';
    }

    const msgEl = document.createElement('div');
    msgEl.className = 'message' + (isOwn ? ' own' : '');
    if (hasSig && !sigValid && !decryptFailed) {
      msgEl.className += ' forged-warning';
    }
    msgEl.dataset.msgId = msg.id;
    msgEl.dataset.pubkey = msg.pubkey;
    // Build avatar safely
    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'message-avatar';
    if (avatarUrl && /^data:image\/[a-zA-Z+]+;base64,/.test(avatarUrl)) {
      const img = document.createElement('img');
      img.className = 'avatar-img';
      img.src = avatarUrl;
      img.alt = '';
      avatarDiv.appendChild(img);
    } else {
      avatarDiv.textContent = (displayName || '?').charAt(0).toUpperCase();
    }

    // Build message body (badges, timeStr, dateStr, displayContent are all sanitized or static)
    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'message-body';
    bodyDiv.innerHTML = `
        <div class="message-header">
          <span class="msg-author" data-pubkey="${escapeHtml(msg.pubkey)}">${escapeHtml(displayName)}</span>
          <span class="msg-badges">${badges}</span>
          <span class="msg-time" title="${escapeHtml(dateStr)}">${escapeHtml(timeStr)}</span>
          ${isOwn ? '<span class="msg-delivery sent" title="Gesendet">&#10003;</span>' : ''}
        </div>
        <div class="message-content">${displayContent}</div>
    `;

    msgEl.appendChild(avatarDiv);
    msgEl.appendChild(bodyDiv);

    msgEl.dataset.createdAt = String(msg.created_at);

    // Insert in chronological order
    const existingMessages = messagesEl.querySelectorAll('.message');
    let inserted = false;
    for (const existing of existingMessages) {
      const existingTime = parseInt(existing.dataset.createdAt || '0', 10);
      if (msg.created_at < existingTime) {
        messagesEl.insertBefore(msgEl, existing);
        inserted = true;
        break;
      }
    }
    if (!inserted) {
      messagesEl.appendChild(msgEl);
    }

    const isNearBottom = messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 100;
    if (isNearBottom || isOwn) {
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }
  }

  function formatContent(text) {
    let formatted = escapeHtml(text);
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/`(.*?)`/g, '<code>$1</code>');
    formatted = formatted.replace(/(https?:\/\/[^\s<>"']+)/g, (match) => {
      try {
        const url = new URL(match);
        // Nur http: und https: erlauben
        if (url.protocol === 'http:' || url.protocol === 'https:') {
          return `<a href="${match}" target="_blank" rel="noopener noreferrer">${match}</a>`;
        }
      } catch {}
      return match; // Bei ungültiger URL: Text unverändert lassen
    });
    formatted = formatted.replace(/\n/g, '<br>');
    return formatted;
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function getCurrentChannel() {
    return currentChannel;
  }

  function getDefaultChannels() {
    return DEFAULT_CHANNELS;
  }

  function getNicknameCache() {
    return nicknameCache;
  }

  return {
    init,
    switchChannel,
    sendMessage,
    publishNickname,
    getDisplayName,
    getAvatarUrl,
    setLocalAvatar,
    getCurrentChannel,
    getDefaultChannels,
    getNicknameCache,
    renderMessage
  };
})();
